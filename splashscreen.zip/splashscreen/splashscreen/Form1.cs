﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace splashscreen
{
    public partial class Form1 : Form
    {
        bool show = true;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Interval = 5000;//5 seconds
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if(show==true)
            {
                pictureBox1.Hide();
                show = false;
            }
        }
    }
}
